const moduleThree = () => {
  console.log('init moduleThree 3333');
};

const moduleThreeVersionTwo = () => {
  console.log('init moduleThreeVersionTwo');
};

export {moduleThree, moduleThreeVersionTwo};
