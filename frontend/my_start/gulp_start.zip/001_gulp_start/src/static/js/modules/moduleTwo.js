const moduleTwo = () => {
  console.log('init moduleTwo 2222');
};

export default moduleTwo;