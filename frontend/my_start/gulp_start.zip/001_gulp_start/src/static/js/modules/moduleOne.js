const activeClass = 'active',
      inActiveClass = 'inactive',
      showClass = 'show',
      hideClass = 'hide';

const moduleOne = () => {
  console.log('init moduleOne 1111');
};

export {moduleOne, showClass};